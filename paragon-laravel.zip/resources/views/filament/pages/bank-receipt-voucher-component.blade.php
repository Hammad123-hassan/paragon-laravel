<x-filament-panels::page>
   @livewire('account.bank-receipt-voucher-component')
</x-filament-panels::page>
