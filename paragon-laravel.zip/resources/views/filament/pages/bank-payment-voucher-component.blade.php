<x-filament-panels::page>
   @livewire('account.bank-payment-voucher-component')
</x-filament-panels::page>
