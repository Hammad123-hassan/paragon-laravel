<x-filament-panels::page>
   @livewire('account.voucher-report-component')
</x-filament-panels::page>