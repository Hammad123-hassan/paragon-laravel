<x-filament-panels::page>
   @livewire('account.ledger-component')
</x-filament-panels::page>
