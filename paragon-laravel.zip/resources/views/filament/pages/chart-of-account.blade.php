<x-filament-panels::page>
   @livewire('account.chart-of-account-component')
</x-filament-panels::page>
