<x-filament-panels::page>
   @livewire('account.checkbook-component')
</x-filament-panels::page>
