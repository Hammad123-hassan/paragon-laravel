<x-filament-panels::page>
   @livewire('account.cash-receipt-voucher-component')
</x-filament-panels::page>
