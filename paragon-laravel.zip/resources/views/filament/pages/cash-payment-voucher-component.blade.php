<x-filament-panels::page>
   @livewire('account.cash-payment-voucher-component')
</x-filament-panels::page>
