<x-filament-panels::page>
   @livewire('account.jv-voucher-component')
</x-filament-panels::page>
