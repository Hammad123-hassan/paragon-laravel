<x-filament-panels::page>
   @livewire('account.trial-component')
</x-filament-panels::page>
