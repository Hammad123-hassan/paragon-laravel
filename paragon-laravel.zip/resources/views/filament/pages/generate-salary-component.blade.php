<x-filament-panels::page>
   @livewire('salary.generate-salary-component')
</x-filament-panels::page>
