<x-filament-panels::page>
   @livewire('custom-chat')

</x-filament-panels::page>
