<style>
    .fi-simple-layout {
        /* background: black !important; */
        background-image: url('/background.jpg');
        background-size: cover;
        background-repeat: no-repeat;
    }
</style>