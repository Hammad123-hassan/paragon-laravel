<div class="">



    <div class="shadow bg-white rounded-tr-lg rounded-tl-lg">
        <!-- Content Header (Page header) -->
        <section class="content-header ">
            <div class="flex items-center gap-3 py-3 px-4  rounded-tr-lg rounded-tl-lg bg-[#00969B]">
                <img src="/voucher.svg" alt="" class="h-[25px]">

                <h1 class="breadcrumb-item text-sm text-white text-center  font-bold">Trail</h1>
            </div>
        </section>
        <!-- Main content -->
        <section>
            <div class="p-4 overflow-x-auto">
                <table class="table table-hover w-full whitespace-nowrap">
                    <thead>
                        <tr class="">
                            <th class="text-start p-3 font-bold text-xs text-black text-xs border">
                                Account
                            </th>
                            <th class="text-start p-3 font-bold text-xs text-black text-xs border">
                                Debit
                            </th>
                            <th class="text-start p-3 font-bold text-xs text-black text-xs border">
                                Credit
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $totalDebit = 0;
                            $totalCredit = 0;
                        @endphp
        
                        @foreach ($levelThree as $item)
                            <tr>
                                <td class="text-start p-4 py-3 font-semibold text-xs text-[#005974] border">
                                    <span class="text-red-500 text-sm font-bold">{{ $item->subAccountGet() }}</span>
                                    <span class="text-blue-500 text-xs font-medium">{{ $item->mainhead }}</span>
                                    {{ $item->id }}
                                    <span class="text-black">{{ $item->account_number }}</span>
                                    {{ $item->title }}
                                </td>
                                <td class="text-start p-4 py-3 font-semibold text-xs text-[#005974] border">
                                    @if ($item->trial() > 0)
                                        {{ number_format(abs($item->trial())) }}
                                        @php $totalDebit += abs($item->trial()); @endphp
                                    @endif
                                </td>
                                <td class="text-start p-4 py-3 font-semibold text-xs text-[#005974] border">
                                    @if ($item->trial() < 0)
                                        {{ number_format(abs($item->trial())) }}
                                        @php $totalCredit += abs($item->trial()); @endphp
                                    @endif
                                </td>
                            </tr>
                        @endforeach
        
                        <tr>
                            <td class="text-start p-4 py-3 font-bold text-xs text-black border">
                                Total
                            </td>
                            <td class="text-start p-4 py-3 font-bold text-xs text-black border">
                                {{ number_format($totalDebit) }}
                            </td>
                            <td class="text-start p-4 py-3 font-bold text-xs text-black border">
                                {{ number_format($totalCredit) }}
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        
      
    </div>
</div>
