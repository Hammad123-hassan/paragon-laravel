<?php

namespace App\Livewire\Salary;

use Livewire\Component;

class GenerateSalaryComponent extends Component
{
    public function render()
    {
        return view('livewire.salary.generate-salary-component');
    }
}
