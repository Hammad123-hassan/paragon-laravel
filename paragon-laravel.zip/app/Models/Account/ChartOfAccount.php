<?php

namespace App\Models\Account;

use App\Models\Campus;
use App\Models\Branch;
use App\Models\VoucherDetail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChartOfAccount extends Model
{
    use HasFactory;

    public $appends = ['mainhead'];

    public static $levels = 3;

    public function subAccounts()
    {
        return $this->hasMany(ChartOfAccount::class, 'parent_chart_of_account_id', 'id');
    }

    public static function mainAccounts()
    {
        return self::where('level', 1)->with('subAccounts.subAccounts.subAccounts');
    }

    public function mainAccountGet()
    {
        return ChartOfAccount::where('id', $this->parent_chart_of_account_id)->pluck('title')->first();
    }
    public function subAccountGet()
    {
        return ChartOfAccount::where('id', $this->main_chart_of_account_id)->pluck('title')->first();
    }

    public function trial()
    {
        $debit = VoucherDetail::where('account_id', $this->id)->sum('debit_amount');
        $credit = VoucherDetail::where('account_id', $this->id)->sum('credit_amount');
        return $debit - $credit;
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function getMainheadAttribute()
    {
        return $this->mainAccountGet();
    }
}
